
package xyz.attendance.management.system;

public class XYZAttendanceManagementSystem {

 
    public static void main(String[] args) {
        WelcomePage l = new WelcomePage();
        l.setVisible(true);
      
    }
    
}
