
package xyz.attendance.management.system;

import javax.swing.JOptionPane;


public class LoginPage extends javax.swing.JFrame {

  
    public LoginPage() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnEnter1 = new javax.swing.JButton();
        btnReset = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        lblPassword = new javax.swing.JLabel();
        psdPassword = new javax.swing.JPasswordField();
        lblID = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));
        jPanel1.setLayout(null);
        jPanel1.add(jLabel2);
        jLabel2.setBounds(422, 54, 0, 0);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/xyz/attendance/management/system/Picture/Dr_Search.png"))); // NOI18N
        jPanel1.add(jLabel4);
        jLabel4.setBounds(360, 40, 260, 260);

        btnEnter1.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        btnEnter1.setText("Enter");
        btnEnter1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnter1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnEnter1);
        btnEnter1.setBounds(40, 250, 80, 25);

        btnReset.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        btnReset.setText("Reset");
        btnReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetActionPerformed(evt);
            }
        });
        jPanel1.add(btnReset);
        btnReset.setBounds(150, 250, 80, 25);

        btnBack.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        btnBack.setText("Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        jPanel1.add(btnBack);
        btnBack.setBounds(260, 250, 90, 25);

        lblPassword.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblPassword.setText("Password:");
        jPanel1.add(lblPassword);
        lblPassword.setBounds(60, 160, 90, 22);

        psdPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                psdPasswordActionPerformed(evt);
            }
        });
        jPanel1.add(psdPassword);
        psdPassword.setBounds(160, 160, 215, 30);

        lblID.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblID.setText("TP Number/ ID:");
        jPanel1.add(lblID);
        lblID.setBounds(10, 120, 130, 22);

        txtName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNameActionPerformed(evt);
            }
        });
        jPanel1.add(txtName);
        txtName.setBounds(160, 120, 215, 30);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setText("XYZ UNIVERSITY LOGIN FORM");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(180, 10, 280, 30);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 640, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 350, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(656, 389));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnEnter1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnter1ActionPerformed

        AdminClass log = new  AdminClass();
        AdminMenu ad = new AdminMenu();
        LecturerClass ll = new LecturerClass();
        LecturerMenu ls = new LecturerMenu();
        StudentClass ww = new StudentClass();
        StudentMenu vv = new StudentMenu();
       

        if(log.loginpass(txtName.getText(), psdPassword.getText())==true)
        {
            ad.setVisible(true);
            this.dispose();
        }
        
        else if(ll.loginpass(txtName.getText(), psdPassword.getText())==true)
        {
             ls.setVisible(true);
             this.dispose();
                    
        }
        
        else if(ww.loginpass(txtName.getText(), psdPassword.getText())==true)
        {
             vv.setVisible(true);
             this.dispose();
                    
        }
       
         else
        {
            JOptionPane.showMessageDialog(null,"Username or Password was not correct");
        }  
        
        
       
        
    }//GEN-LAST:event_btnEnter1ActionPerformed

    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetActionPerformed

    }//GEN-LAST:event_btnResetActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
         WelcomePage LoginPage = new  WelcomePage();
         LoginPage.setVisible(true);
         dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    private void psdPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_psdPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_psdPasswordActionPerformed

    private void txtNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNameActionPerformed

  
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LoginPage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnEnter1;
    private javax.swing.JButton btnReset;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblID;
    private javax.swing.JLabel lblPassword;
    private javax.swing.JPasswordField psdPassword;
    private javax.swing.JTextField txtName;
    // End of variables declaration//GEN-END:variables
}
