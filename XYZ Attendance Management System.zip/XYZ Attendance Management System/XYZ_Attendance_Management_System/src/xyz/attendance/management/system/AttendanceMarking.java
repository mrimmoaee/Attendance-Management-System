
package xyz.attendance.management.system;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.swing.DefaultCellEditor;
import javax.swing.JComboBox;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableColumn;
import java.util.*;
import java.text.*;
import javax.swing.SpinnerDateModel;
import java.util.Calendar;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;


public class AttendanceMarking extends javax.swing.JFrame {

    public AttendanceMarking() {
        initComponents();
        
        showDate();
       
        
        String[] Attendance = {"Present","Absent","Late"};
        JComboBox comboBox=new JComboBox(Attendance);
        TableColumn col = AttendanceTable.getColumnModel().getColumn(2);
        TableCellEditor tc = new DefaultCellEditor(comboBox);
        col.setCellEditor(tc);
        
    }
    
    
    
    void showDate(){
        
        Date d = new Date();
        SimpleDateFormat s = new SimpleDateFormat("dd-MM-yyyy");
        lblDate.setText(s.format(d));
    }
    
    


 private DefaultTableModel setTable(){
     
       DefaultTableModel model =new DefaultTableModel();
       model = (DefaultTableModel)AttendanceTable.getModel();
       return model;
 

   }
 
 
 
  //AttendanceClass mm = new AttendanceClass(StudentName,TPNumber,Date,Starttime,Endtime,Intakecode,Module);
 
 
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jInternalFrame1 = new javax.swing.JInternalFrame();
        lblDate = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        combModule = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        lblDate1 = new javax.swing.JLabel();
        Date date = new Date();
        SpinnerDateModel sm =
        new SpinnerDateModel(date, null, null, Calendar.HOUR_OF_DAY);
        JSpinner1 = new javax.swing.JSpinner(sm);
        Date time = new Date();
        SpinnerDateModel mm =
        new SpinnerDateModel(date, null, null, Calendar.HOUR_OF_DAY);
        JSpinner2 = new javax.swing.JSpinner(mm);
        combIntake = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();
        btnBack = new javax.swing.JButton();
        btnSave = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        AttendanceTable = new javax.swing.JTable();

        jInternalFrame1.setVisible(true);

        javax.swing.GroupLayout jInternalFrame1Layout = new javax.swing.GroupLayout(jInternalFrame1.getContentPane());
        jInternalFrame1.getContentPane().setLayout(jInternalFrame1Layout);
        jInternalFrame1Layout.setHorizontalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jInternalFrame1Layout.setVerticalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        lblDate.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        getContentPane().add(lblDate);
        lblDate.setBounds(58, 11, 131, 20);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel3.setText("End Time:");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(303, 11, 72, 20);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setText("Start Time:");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(545, 11, 83, 20);

        combModule.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ENTS", "OODJ", "SAAD" }));
        getContentPane().add(combModule);
        combModule.setBounds(543, 74, 132, 29);

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel5.setText("Module:");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(465, 77, 74, 20);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel6.setText("Intake Code:");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(58, 77, 106, 20);

        lblDate1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblDate1.setText("Date:");
        getContentPane().add(lblDate1);
        lblDate1.setBounds(10, 11, 42, 20);

        JSpinner.DateEditor de = new JSpinner.DateEditor(JSpinner1, "HH:mm:ss");
        JSpinner1.setEditor(de);
        getContentPane().add(JSpinner1);
        JSpinner1.setBounds(379, 12, 118, 30);

        JSpinner.DateEditor ee = new JSpinner.DateEditor(JSpinner2, "HH:mm:ss");
        JSpinner2.setEditor(ee);
        getContentPane().add(JSpinner2);
        JSpinner2.setBounds(632, 12, 118, 30);

        combIntake.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "UC1704SE", "UC1704AI", "UC1605IT" }));
        combIntake.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combIntakeActionPerformed(evt);
            }
        });
        getContentPane().add(combIntake);
        combIntake.setBounds(168, 74, 129, 29);

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));

        btnBack.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnBack.setText("Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        btnSave.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnSave.setText("Save");
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });

        AttendanceTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student Name", "TP Number", "Attendance"
            }
        ));
        jScrollPane1.setViewportView(AttendanceTable);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(373, 373, 373)
                        .addComponent(btnSave, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 774, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(63, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(130, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnSave)
                .addGap(18, 18, 18)
                .addComponent(btnBack)
                .addGap(14, 14, 14))
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 890, 530);

        setSize(new java.awt.Dimension(897, 562));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    
    
    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed
        
        String Date = (lblDate.getText() + (";"));
        String StartTime = (JSpinner1.getName()+ (";"));
        String EndTime = (JSpinner2.getName()+ (";"));
        String IntakeCode = (combIntake.getSelectedItem().toString() + (";"));
        String Module = (combModule.getSelectedItem().toString() + (";"));
        
       
        
        try {
            File file = new File(combIntake.getSelectedItem() + "-Attendance" +".txt");

            if (!file.exists()) {
                file.createNewFile();
            }

            FileWriter fw = new FileWriter(file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);

           
            bw.write(System.getProperty("line.separator"));
            

            for (int i = 0; i < AttendanceTable.getRowCount(); i++) {
                
              
               
                for (int j = 0; j < AttendanceTable.getColumnCount(); j++) {

                   
                   
                    
                    bw.write(AttendanceTable.getModel().getValueAt(i, j) + ";");

                }
               
              
                bw.write(Module);
                bw.write(Date);
                bw.write(System.getProperty("line.separator"));
            }

            bw.close();
            fw.close();

            JOptionPane.showMessageDialog(null, "New Attendance Saved!");

        } catch (Exception ex) {

        }
  
        
    }//GEN-LAST:event_btnSaveActionPerformed

    private void combIntakeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combIntakeActionPerformed
        
        DefaultTableModel model = setTable();
        model = (DefaultTableModel) AttendanceTable.getModel();

        String cd = (String) combIntake.getSelectedItem();
        model.setRowCount(0);

        String intakefile = cd + ".txt";
        try {
            BufferedReader input = new BufferedReader(new FileReader(intakefile));
            String line = input.readLine();
            System.out.println(line);
            while (line != null) {
                String[] records = line.split(";");
                String StudentName = records[0];
                String TPNumber = records[1];
                
               
                model.addRow(new Object[]{StudentName, TPNumber});
                line = input.readLine();
            }
            input.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error");
        }
         
        
        
        
    }//GEN-LAST:event_combIntakeActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
         LecturerMenu  AttendanceMarking = new  LecturerMenu ();
         AttendanceMarking.setVisible(true);
         dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AttendanceMarking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AttendanceMarking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AttendanceMarking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AttendanceMarking.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AttendanceMarking().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable AttendanceTable;
    private javax.swing.JSpinner JSpinner1;
    private javax.swing.JSpinner JSpinner2;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnSave;
    private javax.swing.JComboBox<String> combIntake;
    private javax.swing.JComboBox<String> combModule;
    private javax.swing.JInternalFrame jInternalFrame1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblDate;
    private javax.swing.JLabel lblDate1;
    // End of variables declaration//GEN-END:variables
}
