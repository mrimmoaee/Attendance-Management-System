
package xyz.attendance.management.system;

public class AbsentReasonClass {
    
    public String Name;
    public String TPNumber;
    public String Intakecode;
    public String Module;
    public String LecturerName;
    public String Reason;

    AbsentReasonClass() {

    }

    AbsentReasonClass(String StudentName, String TPNumber, String Intakecode, String Module, String LecturerName, String Reason) {

        this.Name = StudentName;
        this.TPNumber = TPNumber;
        this.Intakecode = Intakecode;
        this.Module = Module;
        this.LecturerName = LecturerName;
        this.Reason = Reason;
        
        
    }

    public String getStudentName() {
        return Name;
    }

    public String getTPNumber() {
        return TPNumber;
    }

    public String getIntakecode() {
        return Intakecode;
    }

    public String getModule() {
        return Module;
    }

    public String getLecturername() {
        return LecturerName;
    }

    public String getReason() {
        return Reason;
    }
    
}
