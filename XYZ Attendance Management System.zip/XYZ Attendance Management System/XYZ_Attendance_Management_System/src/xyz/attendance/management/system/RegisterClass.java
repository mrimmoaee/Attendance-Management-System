
package xyz.attendance.management.system;

public class RegisterClass {
    
    public String name;
    public String ID;
    public String intakecode;
    public String gender;
    public String Module;
    public String phonenumber;
    public String password;
    public String email;
    
    
  
    
    
    RegisterClass(){
        
    }
    
    RegisterClass(String name,String ID,String intakecode,String email,String phonenumber,String password,String gender,String Module)
    {
        this.name =name;
        this.ID= ID;
        this.intakecode=intakecode;
        this.gender= gender;
        this.Module= Module;
        this.phonenumber = phonenumber;
        this.password = password;
        this.email = email;
    }
    
    public String getname()
    {
        return name;
    }
    
    public String getID()
    {
        return ID;
    }
    
    public String getintakecode()
    {
        return intakecode;
    }
    
    public String getgender()
    {
       return gender; 
    }
    
    public String getModule()
    {
       return Module; 
    }
    
     public String getphonenumber()
    {
        return phonenumber;
    }
    
    public String getpassword()
    {
       return password; 
    }
    
    public String getemail()
    {
       return email; 
    }
    
    
}
