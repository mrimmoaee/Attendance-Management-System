
package xyz.attendance.management.system;

import javax.swing.JOptionPane;


public class AdminMenu extends javax.swing.JFrame {

   
    public AdminMenu() {
        initComponents();
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnLogout = new javax.swing.JButton();
        btnRecord = new javax.swing.JButton();
        btnViewattendance1 = new javax.swing.JButton();
        btnAbsentreason1 = new javax.swing.JButton();
        lblMail = new javax.swing.JLabel();
        lblAttandance1 = new javax.swing.JLabel();
        lblAttandance2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setForeground(new java.awt.Color(204, 204, 204));
        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel1.setText("Login as: ADMIN");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(10, 0, 120, 20);

        btnLogout.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnLogout.setText("Logout");
        btnLogout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLogoutActionPerformed(evt);
            }
        });
        jPanel1.add(btnLogout);
        btnLogout.setBounds(440, 10, 90, 30);

        btnRecord.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnRecord.setText("Register");
        btnRecord.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRecordActionPerformed(evt);
            }
        });
        jPanel1.add(btnRecord);
        btnRecord.setBounds(170, 300, 160, 30);

        btnViewattendance1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnViewattendance1.setText("Attendance");
        btnViewattendance1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewattendance1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnViewattendance1);
        btnViewattendance1.setBounds(80, 140, 150, 30);

        btnAbsentreason1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnAbsentreason1.setText("Absent Reason");
        btnAbsentreason1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAbsentreason1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnAbsentreason1);
        btnAbsentreason1.setBounds(280, 140, 160, 30);

        lblMail.setIcon(new javax.swing.ImageIcon(getClass().getResource("/xyz/attendance/management/system/Picture/close-envelope.png"))); // NOI18N
        jPanel1.add(lblMail);
        lblMail.setBounds(320, 50, 70, 90);

        lblAttandance1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/xyz/attendance/management/system/Picture/save-icon.png"))); // NOI18N
        jPanel1.add(lblAttandance1);
        lblAttandance1.setBounds(220, 210, 80, 90);

        lblAttandance2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/xyz/attendance/management/system/Picture/Attendance.png"))); // NOI18N
        jPanel1.add(lblAttandance2);
        lblAttandance2.setBounds(130, 50, 70, 90);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 546, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 387, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(562, 426));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnRecordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRecordActionPerformed
        Record  AdminMenu = new  Record();
        AdminMenu.setVisible(true);
        dispose();
    }//GEN-LAST:event_btnRecordActionPerformed

    private void btnLogoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLogoutActionPerformed
        int logout = JOptionPane.showConfirmDialog(null,"Do you want to logout ID?","Logout",
            JOptionPane.YES_NO_OPTION);
        if (logout == JOptionPane.YES_OPTION)
        {
          LoginPage  AdminMenu = new  LoginPage ();
          AdminMenu.setVisible(true);
          dispose();
        }
    }//GEN-LAST:event_btnLogoutActionPerformed

    private void btnViewattendance1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewattendance1ActionPerformed
        ViewAndModifyAttendance  AdminMenu = new  ViewAndModifyAttendance ();
        AdminMenu .setVisible(true);
        dispose();
    }//GEN-LAST:event_btnViewattendance1ActionPerformed

    private void btnAbsentreason1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAbsentreason1ActionPerformed
        ViewAbsentReason  AdminMenu = new  ViewAbsentReason  ();
        AdminMenu .setVisible(true);
        dispose();
    }//GEN-LAST:event_btnAbsentreason1ActionPerformed

    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAbsentreason1;
    private javax.swing.JButton btnLogout;
    private javax.swing.JButton btnRecord;
    private javax.swing.JButton btnViewattendance1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblAttandance1;
    private javax.swing.JLabel lblAttandance2;
    private javax.swing.JLabel lblMail;
    // End of variables declaration//GEN-END:variables
}
