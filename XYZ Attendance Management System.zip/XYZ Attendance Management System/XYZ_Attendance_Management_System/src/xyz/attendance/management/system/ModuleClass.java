
package xyz.attendance.management.system;

public class ModuleClass {
    
    public String ModuleID;
    
    ModuleClass(){
        
    }
    
    ModuleClass(String ModuleID){
        this.ModuleID = ModuleID;
    }
    
    public String getModuleID()
    {
        return ModuleID;
    }
    
    
    
    
    
}
