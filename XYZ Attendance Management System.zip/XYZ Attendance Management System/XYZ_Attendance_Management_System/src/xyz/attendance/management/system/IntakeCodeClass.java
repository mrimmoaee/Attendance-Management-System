
package xyz.attendance.management.system;

public class IntakeCodeClass {
    
    public String Intakecode;
    
    IntakeCodeClass(){
        
    }
   
    IntakeCodeClass(String Intakecode){
        this.Intakecode= Intakecode;
    }
    
    public String getModuleID()
    {
        return Intakecode;
    }
    
}
