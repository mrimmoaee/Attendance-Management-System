package xyz.attendance.management.system;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author SHAMEE
 */
public class LecturerRecord extends javax.swing.JFrame {

 
    public LecturerRecord() {
        initComponents();
    }
    
     private void filter(String txt){
        
        DefaultTableModel table = (DefaultTableModel)LecturerRecordTable.getModel();
        String search = txtSearch.getText().toLowerCase();
        TableRowSorter<DefaultTableModel> tr = new TableRowSorter<DefaultTableModel>(table);
        LecturerRecordTable.setRowSorter(tr);
        tr.setRowFilter(RowFilter.regexFilter(search));
        
    }

    DefaultTableModel model;
    
    private void setTable(){
        model = (DefaultTableModel)LecturerRecordTable.getModel();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lblSearchstudent = new javax.swing.JLabel();
        txtSearch = new javax.swing.JTextField();
        btnDelete = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        btnSave = new javax.swing.JButton();
        btnModify1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        LecturerRecordTable = new javax.swing.JTable();
        lblFullname2 = new javax.swing.JLabel();
        lblFullname3 = new javax.swing.JLabel();
        lblFullname4 = new javax.swing.JLabel();
        lblFullname5 = new javax.swing.JLabel();
        lblFullname6 = new javax.swing.JLabel();
        lblFullname7 = new javax.swing.JLabel();
        lblFullname8 = new javax.swing.JLabel();
        lblFullname9 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        txtTPnumber = new javax.swing.JTextField();
        txtPassword = new javax.swing.JTextField();
        txtMobileNumber = new javax.swing.JTextField();
        combGender = new javax.swing.JComboBox<>();
        combIntakecode = new javax.swing.JComboBox<>();
        comModule = new javax.swing.JComboBox<>();
        btnView2 = new javax.swing.JButton();
        txtFullname = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel1.setText("Login as: ADMIN");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, 0, 120, 20);

        lblSearchstudent.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        lblSearchstudent.setText("Search By Name / ID Number : ");
        jPanel1.add(lblSearchstudent);
        lblSearchstudent.setBounds(10, 40, 246, 22);

        txtSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSearchActionPerformed(evt);
            }
        });
        txtSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtSearchKeyPressed(evt);
            }
        });
        jPanel1.add(txtSearch);
        txtSearch.setBounds(260, 40, 460, 30);

        btnDelete.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        jPanel1.add(btnDelete);
        btnDelete.setBounds(760, 410, 90, 25);

        btnBack.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnBack.setText("Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        jPanel1.add(btnBack);
        btnBack.setBounds(1100, 450, 90, 25);

        btnSave.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnSave.setText("Save");
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });
        jPanel1.add(btnSave);
        btnSave.setBounds(400, 410, 90, 25);

        btnModify1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnModify1.setText("Modify");
        btnModify1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModify1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnModify1);
        btnModify1.setBounds(1030, 370, 90, 25);

        LecturerRecordTable.setAutoCreateRowSorter(true);
        LecturerRecordTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Lecturer Name", "Lecturer ID", "Intake Code", "Module Name", "Gender", "Password", "Mobile Number", "Email"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, true, true, true, true, true, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        LecturerRecordTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LecturerRecordTableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(LecturerRecordTable);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(10, 100, 840, 300);

        lblFullname2.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblFullname2.setText("Gender:");
        jPanel1.add(lblFullname2);
        lblFullname2.setBounds(920, 230, 80, 22);

        lblFullname3.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblFullname3.setText("Full Name:");
        jPanel1.add(lblFullname3);
        lblFullname3.setBounds(900, 110, 80, 22);

        lblFullname4.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblFullname4.setText("ID Number:");
        jPanel1.add(lblFullname4);
        lblFullname4.setBounds(890, 140, 100, 22);

        lblFullname5.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblFullname5.setText("Intake Code:");
        jPanel1.add(lblFullname5);
        lblFullname5.setBounds(880, 170, 100, 22);

        lblFullname6.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblFullname6.setText("Module Name:");
        jPanel1.add(lblFullname6);
        lblFullname6.setBounds(870, 200, 120, 22);

        lblFullname7.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblFullname7.setText("Password: ");
        jPanel1.add(lblFullname7);
        lblFullname7.setBounds(900, 260, 80, 22);

        lblFullname8.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblFullname8.setText("Mobile Number:");
        jPanel1.add(lblFullname8);
        lblFullname8.setBounds(860, 290, 130, 22);

        lblFullname9.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        lblFullname9.setText("Email:");
        jPanel1.add(lblFullname9);
        lblFullname9.setBounds(930, 320, 80, 22);
        jPanel1.add(txtEmail);
        txtEmail.setBounds(990, 320, 180, 20);
        jPanel1.add(txtTPnumber);
        txtTPnumber.setBounds(990, 140, 180, 20);
        jPanel1.add(txtPassword);
        txtPassword.setBounds(990, 260, 180, 20);
        jPanel1.add(txtMobileNumber);
        txtMobileNumber.setBounds(990, 290, 180, 20);

        combGender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Female", "Male" }));
        jPanel1.add(combGender);
        combGender.setBounds(990, 230, 180, 20);

        combIntakecode.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "UC1704SE", "UC1704AI", "UC1605IT" }));
        jPanel1.add(combIntakecode);
        combIntakecode.setBounds(990, 170, 180, 20);

        comModule.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "OODJ", "ENTS", "SAAD" }));
        jPanel1.add(comModule);
        comModule.setBounds(990, 200, 180, 20);

        btnView2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnView2.setText("View");
        btnView2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnView2ActionPerformed(evt);
            }
        });
        jPanel1.add(btnView2);
        btnView2.setBounds(10, 410, 90, 25);
        jPanel1.add(txtFullname);
        txtFullname.setBounds(990, 110, 180, 20);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1196, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 483, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(1212, 522));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
          int delete = JOptionPane.showConfirmDialog(null,"Do you want to Delete ID?","Delete",
          JOptionPane.YES_NO_OPTION);
          if (delete == JOptionPane.YES_OPTION)
        {
              {
            int SelectedRowIndex = LecturerRecordTable.getSelectedRow();
            model.removeRow(SelectedRowIndex);
            
              txtFullname.setText("");
              txtTPnumber.setText("");
              txtPassword.setText("");
              txtMobileNumber.setText("");
              txtEmail.setText("");
            
              JOptionPane.showMessageDialog(null, "Deleted Successfully!");
             
              }    
        
        }    
            
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        Record  LecturerRecord = new  Record ();
        LecturerRecord .setVisible(true);
        dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed
        String FullName = (txtFullname.getText() + (";"));
        String IDNumber = (txtTPnumber.getText()+ (";"));
        String IntakeCode = (combIntakecode.getSelectedItem().toString() + (";"));
        String Gender = (combGender.getSelectedItem().toString() + (";"));
        String ModuleName = (comModule.getSelectedItem().toString() + (";"));
        String Password = (txtPassword.getText()+ (";"));
        String MobileNumber = (txtMobileNumber.getText() + (";"));
        String Email =  (txtEmail.getText().trim() + (";"));

        RegisterClass lecturer = new  RegisterClass (FullName,IDNumber,IntakeCode,ModuleName,Gender,Password,MobileNumber,Email);

        try {

            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter( "Lecturer.txt",true)));

            {
                //pw.write(System.getProperty("line.separator"));
                pw.write(FullName);
                pw.write(IDNumber);
                pw.write(IntakeCode);
                pw.write(ModuleName);
                pw.write(Gender);
                pw.write(Password);
                pw.write(MobileNumber);
                pw.write(Email);
                
                pw.println();
                pw.close();
                
                txtFullname.setText("");
                txtTPnumber.setText("");
                txtPassword.setText("");
                txtMobileNumber.setText("");
                txtEmail.setText("");

                JOptionPane.showMessageDialog(null, "New Lecturer Added");

            }

        }

        catch(Exception e) {
            JOptionPane.showMessageDialog(null, "No New Lecturer Added");
        }

        

    }//GEN-LAST:event_btnSaveActionPerformed

    private void btnModify1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModify1ActionPerformed
        String searchFullname = txtFullname.getText();
        String newPassword = txtPassword.getText();
        String newMobileNumber = txtMobileNumber.getText();
        String  newEmail  =txtEmail.getText();
        
        
        
        
      //temporary array to hold the data that is read from file 
        ArrayList<String> tempArray = new ArrayList<>();
        
      
        try {
            try (FileReader fr = new FileReader("Lecturer.txt")) {
                Scanner reader = new Scanner(fr);
                String line;
                String[] lineArr;

                while ((line = reader.nextLine()) != null) {
                    //splite each line to check if the search name is present.
                    lineArr = line.split(";");
                    if (lineArr[0].equals(searchFullname)) {
                        
                        //if the search name is present, add the old data
                        //plus the new data in to the temp array
                        tempArray.add(
                                lineArr[0] + ";"
                                + lineArr[1] + ";"
                                + lineArr[2] + ";"
                                + lineArr[3] + ";"
                                + lineArr[4] + ";"        
                                + newPassword  + ";"
                                + newMobileNumber  + ";"
                                + newEmail);
                              
                              
                    } else {
                        
                        //if the search id doennot match, add the line as it is
                        tempArray.add(line);
                    }
                }

                fr.close();

            } catch (Exception e) {

            }
        } catch (Exception e) {

        }
        
         
        try{
            
            //open the print writer to write the data in temp array back to the file
            try(PrintWriter pr = new PrintWriter("Lecturer.txt")){
                
                for (String str : tempArray) {
                    pr.println(str);

                    JOptionPane.showMessageDialog(null, "Lecturer Record Updated");
                }
                
                //close the file 

                pr.close();
                
            } catch (Exception e) {

           }
            
        }catch (Exception e) {

        } 
    }//GEN-LAST:event_btnModify1ActionPerformed

    private void btnView2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnView2ActionPerformed
         model = (DefaultTableModel) LecturerRecordTable.getModel();
         model.setRowCount(0);
 
       

        try {
            BufferedReader input = new BufferedReader(new FileReader("Lecturer.txt"));
            String line = input.readLine();
            
            
            
            
            while (line != null) {
                //System.out.println(line);

                String[] records = line.split(";");

                String FullName = records[0];
                String IDNumber = records[1];
                String IntakeCode = records[2];
                String Gender = records[3];
                String ModuleName = records[4];
                String Password = records[5];
                String MobileNumber = records[6];
                String Email = records[7];
                
                model.addRow(new Object[]{FullName, IDNumber, IntakeCode, Gender, ModuleName,Password, MobileNumber, Email});
                line = input.readLine();
            }
            input.close();

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }//GEN-LAST:event_btnView2ActionPerformed

    private void LecturerRecordTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_LecturerRecordTableMouseClicked
        int i = LecturerRecordTable.getSelectedRow();
        txtFullname.setText(model.getValueAt(i,0).toString());
        txtTPnumber.setText(model.getValueAt(i,1).toString());
        txtPassword.setText(model.getValueAt(i,5).toString());
        txtMobileNumber.setText(model.getValueAt(i,6).toString());
        txtEmail.setText(model.getValueAt(i,7).toString());
    }//GEN-LAST:event_LecturerRecordTableMouseClicked

    private void txtSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSearchActionPerformed

    private void txtSearchKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSearchKeyPressed
       
         String txt = txtSearch.getText();
        
         filter(txt);
    }//GEN-LAST:event_txtSearchKeyPressed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LecturerRecord.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LecturerRecord.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LecturerRecord.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LecturerRecord.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new LecturerRecord().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable LecturerRecordTable;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnModify1;
    private javax.swing.JButton btnSave;
    private javax.swing.JButton btnView2;
    private javax.swing.JComboBox<String> comModule;
    private javax.swing.JComboBox<String> combGender;
    private javax.swing.JComboBox<String> combIntakecode;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblFullname2;
    private javax.swing.JLabel lblFullname3;
    private javax.swing.JLabel lblFullname4;
    private javax.swing.JLabel lblFullname5;
    private javax.swing.JLabel lblFullname6;
    private javax.swing.JLabel lblFullname7;
    private javax.swing.JLabel lblFullname8;
    private javax.swing.JLabel lblFullname9;
    private javax.swing.JLabel lblSearchstudent;
    private javax.swing.JTextField txtEmail;
    public javax.swing.JTextField txtFullname;
    private javax.swing.JTextField txtMobileNumber;
    private javax.swing.JTextField txtPassword;
    private javax.swing.JTextField txtSearch;
    private javax.swing.JTextField txtTPnumber;
    // End of variables declaration//GEN-END:variables
}
