
package xyz.attendance.management.system;

public class UserClass {
    public String Name;
    public String Email;
    public String PhoneNumber;
    
   
    

    
    public void login()
    {
        
    }
    
    UserClass(String Name,String Email,String PhoneNumber)
    {
        this.Name = Name;
        this.Email = Email;
        this.PhoneNumber = PhoneNumber;
    }
    public String getName()
    {
        return Name;
    }
    public String getEmail()
    {
        return Email;
    }
    
    public String getPhoneNumber()
    {
        return PhoneNumber;
    }
    
    
   
}
