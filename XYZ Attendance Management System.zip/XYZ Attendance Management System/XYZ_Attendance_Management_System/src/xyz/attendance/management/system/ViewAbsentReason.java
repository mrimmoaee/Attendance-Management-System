
package xyz.attendance.management.system;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class ViewAbsentReason extends javax.swing.JFrame {

    
    public ViewAbsentReason() {
        initComponents();
    }

    
    DefaultTableModel model;

    private void setTable() {
        model = (DefaultTableModel) AbsentTable.getModel();
    }
    
    
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        AbsentTable = new javax.swing.JTable();
        btnBack = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        lblName4 = new javax.swing.JLabel();
        comIntake = new javax.swing.JComboBox<>();
        jPanel1 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        AbsentTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "IntakeCode", "Student Name", "TP Number", "Module Name", "Lecturer Name", "Absent Reason"
            }
        ));
        jScrollPane2.setViewportView(AbsentTable);

        getContentPane().add(jScrollPane2);
        jScrollPane2.setBounds(10, 81, 931, 331);

        btnBack.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnBack.setText("Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        getContentPane().add(btnBack);
        btnBack.setBounds(850, 440, 90, 25);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel1.setText("Login as: ADMIN");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(10, 0, 120, 20);

        lblName4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblName4.setText("Intake Code:");
        getContentPane().add(lblName4);
        lblName4.setBounds(10, 30, 90, 20);

        comIntake.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "UC1704SE-AbsentReason", "UC1704AI-AbsentReason", "UC1605IT-AbsentReason" }));
        comIntake.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comIntakeActionPerformed(evt);
            }
        });
        getContentPane().add(comIntake);
        comIntake.setBounds(100, 30, 210, 30);

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 950, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 950, 500);

        setSize(new java.awt.Dimension(967, 535));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        AdminMenu ViewAbsentReason = new  AdminMenu  ();
        ViewAbsentReason .setVisible(true);
        dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    private void comIntakeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comIntakeActionPerformed
          
         model = (DefaultTableModel) AbsentTable.getModel();
        String cd = (String) comIntake.getSelectedItem();

        model.setRowCount(0);

        String intakefile = cd + ".txt";

        try {
            BufferedReader input = new BufferedReader(new FileReader(intakefile));
            String line = input.readLine();
            
            
            
            
            while (line != null) {
                //System.out.println(line);

                String[] records = line.split(";");

                
                String IntakeCode = records[0];
                String StudentName = records[1];
                String TPNumber = records[2];
                String ModuleName = records[3];
                String LecturerName = records[4];
                String AbsentReason = records[5];
                
                
                model.addRow(new Object[]{IntakeCode,StudentName,TPNumber,ModuleName,LecturerName,AbsentReason});
                line = input.readLine();
            }
            input.close();

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error");
        }
    }//GEN-LAST:event_comIntakeActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ViewAbsentReason.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ViewAbsentReason.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ViewAbsentReason.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ViewAbsentReason.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewAbsentReason().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable AbsentTable;
    private javax.swing.JButton btnBack;
    private javax.swing.JComboBox<String> comIntake;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblName4;
    // End of variables declaration//GEN-END:variables
}
