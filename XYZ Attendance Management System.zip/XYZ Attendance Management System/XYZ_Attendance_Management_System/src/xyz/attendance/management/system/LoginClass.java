
package xyz.attendance.management.system;

public class LoginClass {
    
    public String ID;
    protected String Password;
    
    public LoginClass(){
        
    }
    
    public LoginClass (String id, String password)
    {
        this.ID = id;
        this.Password = password;
    }
    
      
    public String geID()
    {
        return ID;
    }
       
    public String gepassword()
    {
        return Password;
    }
    
    
}
