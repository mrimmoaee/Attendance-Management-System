
package xyz.attendance.management.system;


import java.awt.event.ActionEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;



public class StudentRecord extends javax.swing.JFrame {

  
    public StudentRecord() {
        initComponents();
        
        
    }
    
    private void filter(String txt){
        
        DefaultTableModel table = (DefaultTableModel)StudentRecordtable.getModel();
        String search = txtSearch.getText().toLowerCase();
        TableRowSorter<DefaultTableModel> tr = new TableRowSorter<DefaultTableModel>(table);
        StudentRecordtable.setRowSorter(tr);
        tr.setRowFilter(RowFilter.regexFilter(search));
        
    }
    
    public void selectedRows (){
        
        }
    
    
    

   IntakeCodeClass cd = new IntakeCodeClass();
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnDelete = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        StudentRecordtable = new javax.swing.JTable();
        btnModify2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        CombIntake = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        lblModule = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        txtSearch1 = new javax.swing.JTextField();
        btnDelete1 = new javax.swing.JButton();
        btnBack1 = new javax.swing.JButton();
        btnView2 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        StudentRecordtable1 = new javax.swing.JTable();
        btnModify3 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        CombIntake1 = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        txtFullname = new javax.swing.JTextField();
        txtTPnumber = new javax.swing.JTextField();
        txtPassword = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        combIntakecode = new javax.swing.JComboBox<>();
        comGender = new javax.swing.JComboBox<>();
        jLabel18 = new javax.swing.JLabel();
        txtMobilenumber = new javax.swing.JTextField();
        btnSave = new javax.swing.JButton();
        txtSearch = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        combModule = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setText("Select Intake Code :");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(450, 40, 160, 40);

        btnDelete.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnDelete.setText("Delete");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        jPanel1.add(btnDelete);
        btnDelete.setBounds(390, 400, 90, 25);

        btnBack.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnBack.setText("Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });
        jPanel1.add(btnBack);
        btnBack.setBounds(840, 410, 90, 25);

        StudentRecordtable.setAutoCreateRowSorter(true);
        StudentRecordtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "FullName", "TPNumber", "IntakeCode", "Gender", "Module Name", "Password", "MobileNumber", "Email"
            }
        ));
        StudentRecordtable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                StudentRecordtableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(StudentRecordtable);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(10, 100, 670, 280);

        btnModify2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnModify2.setText("Modify");
        btnModify2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModify2ActionPerformed(evt);
            }
        });
        jPanel1.add(btnModify2);
        btnModify2.setBounds(800, 360, 90, 25);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel2.setText("Login as: ADMIN");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(10, 0, 120, 20);

        CombIntake.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "UC1704SE", "UC1605IT", "UC1704AI" }));
        CombIntake.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CombIntakeActionPerformed(evt);
            }
        });
        jPanel1.add(CombIntake);
        CombIntake.setBounds(620, 40, 140, 30);

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel3.setText("Search :");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(10, 40, 100, 40);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setText("Gender:");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(730, 230, 90, 20);

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel5.setText("FullName:");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(710, 110, 80, 20);

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel6.setText("TP Number:");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(700, 140, 90, 20);

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel7.setText("IntakeCode:");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(700, 170, 100, 20);

        lblModule.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        lblModule.setText("Module Name:");
        jPanel1.add(lblModule);
        lblModule.setBounds(690, 200, 90, 20);

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.setLayout(null);

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel9.setText("Select Intake Code :");
        jPanel2.add(jLabel9);
        jLabel9.setBounds(450, 40, 160, 40);

        txtSearch1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtSearch1KeyReleased(evt);
            }
        });
        jPanel2.add(txtSearch1);
        txtSearch1.setBounds(80, 40, 330, 30);

        btnDelete1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnDelete1.setText("Delete");
        btnDelete1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDelete1ActionPerformed(evt);
            }
        });
        jPanel2.add(btnDelete1);
        btnDelete1.setBounds(440, 400, 90, 25);

        btnBack1.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnBack1.setText("Back");
        btnBack1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBack1ActionPerformed(evt);
            }
        });
        jPanel2.add(btnBack1);
        btnBack1.setBounds(660, 400, 90, 25);

        btnView2.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnView2.setText("View");
        btnView2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnView2ActionPerformed(evt);
            }
        });
        jPanel2.add(btnView2);
        btnView2.setBounds(20, 400, 90, 25);

        StudentRecordtable1.setAutoCreateRowSorter(true);
        StudentRecordtable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "FullName", "TPNumber", "CourseName", "MobileNumber", "Email", "Gender"
            }
        ));
        jScrollPane3.setViewportView(StudentRecordtable1);

        jPanel2.add(jScrollPane3);
        jScrollPane3.setBounds(10, 100, 610, 280);

        btnModify3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnModify3.setText("Modify");
        btnModify3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModify3ActionPerformed(evt);
            }
        });
        jPanel2.add(btnModify3);
        btnModify3.setBounds(230, 400, 90, 25);

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel10.setText("Login as: ADMIN");
        jPanel2.add(jLabel10);
        jLabel10.setBounds(10, 0, 120, 20);

        CombIntake1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "UC1704SE", "UC1605IT", "UC1704AI" }));
        CombIntake1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CombIntake1ActionPerformed(evt);
            }
        });
        jPanel2.add(CombIntake1);
        CombIntake1.setBounds(620, 40, 140, 30);

        jLabel11.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel11.setText("Search :");
        jPanel2.add(jLabel11);
        jLabel11.setBounds(10, 40, 100, 40);

        jLabel12.setText("Email:");
        jPanel2.add(jLabel12);
        jLabel12.setBounds(680, 180, 90, 20);

        jLabel13.setText("FullName:");
        jPanel2.add(jLabel13);
        jLabel13.setBounds(680, 100, 50, 20);

        jLabel14.setText("TP Number:");
        jPanel2.add(jLabel14);
        jLabel14.setBounds(680, 120, 70, 20);

        jLabel15.setText("CourseName:");
        jPanel2.add(jLabel15);
        jLabel15.setBounds(680, 140, 70, 20);

        jLabel16.setText("MobileNumber:");
        jPanel2.add(jLabel16);
        jLabel16.setBounds(680, 160, 90, 20);

        jPanel1.add(jPanel2);
        jPanel2.setBounds(0, 0, 0, 0);

        jLabel17.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel17.setText("Email:");
        jPanel1.add(jLabel17);
        jLabel17.setBounds(740, 320, 90, 20);
        jPanel1.add(txtFullname);
        txtFullname.setBounds(810, 110, 130, 20);
        jPanel1.add(txtTPnumber);
        txtTPnumber.setBounds(810, 140, 130, 20);
        jPanel1.add(txtPassword);
        txtPassword.setBounds(810, 260, 130, 20);
        jPanel1.add(txtEmail);
        txtEmail.setBounds(810, 320, 130, 20);

        combIntakecode.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "UC1704SE", "UC1605IT", "UC1704AI" }));
        combIntakecode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combIntakecodeActionPerformed(evt);
            }
        });
        jPanel1.add(combIntakecode);
        combIntakecode.setBounds(810, 170, 130, 20);

        comGender.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Female", "Male" }));
        jPanel1.add(comGender);
        comGender.setBounds(810, 230, 130, 20);

        jLabel18.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel18.setText("MobileNumber:");
        jPanel1.add(jLabel18);
        jLabel18.setBounds(690, 290, 120, 20);
        jPanel1.add(txtMobilenumber);
        txtMobilenumber.setBounds(810, 290, 130, 20);

        btnSave.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btnSave.setText("Save");
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });
        jPanel1.add(btnSave);
        btnSave.setBounds(210, 400, 90, 25);

        txtSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSearchActionPerformed(evt);
            }
        });
        txtSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtSearchKeyReleased(evt);
            }
        });
        jPanel1.add(txtSearch);
        txtSearch.setBounds(80, 50, 230, 30);

        jLabel19.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel19.setText("Password:");
        jPanel1.add(jLabel19);
        jLabel19.setBounds(720, 260, 80, 20);

        combModule.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SAAD", "OODJ", "ENTS" }));
        jPanel1.add(combModule);
        combModule.setBounds(810, 200, 130, 20);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 955, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 447, Short.MAX_VALUE)
        );

        setSize(new java.awt.Dimension(971, 486));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
      
          int delete = JOptionPane.showConfirmDialog(null,"Do you want to Delete ID?","Delete",
          JOptionPane.YES_NO_OPTION);
          if (delete == JOptionPane.YES_OPTION)
        {
             {
            int SelectedRowIndex = StudentRecordtable.getSelectedRow();
            model.removeRow(SelectedRowIndex);
            
              txtFullname.setText("");
              txtTPnumber.setText("");
              txtPassword.setText("");
              txtMobilenumber.setText("");
              txtEmail.setText("");
            
              JOptionPane.showMessageDialog(null, "Deleted Successfully!");
             
              }    
            
            
            
            
            
            
            
            
            
            
            
            
            
            
        
            
        }    
            
            
            
   
    
    }//GEN-LAST:event_btnDeleteActionPerformed

    
    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        Record  StudentRecord = new  Record ();
        StudentRecord .setVisible(true);
        dispose();
    }//GEN-LAST:event_btnBackActionPerformed

    
    DefaultTableModel model;
    
    private void setTable(){
        model = (DefaultTableModel)StudentRecordtable.getModel();
    }
    private void btnModify2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModify2ActionPerformed
       // Modify  StudentRecord = new  Modify ();
      //  StudentRecord.setVisible(true);
      //  dispose();
        
        
        
        
        //get input from the form
        String searchFullname = txtFullname.getText();
        String newPassword = txtPassword.getText();
        String newMobileNumber = txtMobilenumber.getText();
        String  newEmail  =txtEmail.getText();
        
        
        model = (DefaultTableModel) StudentRecordtable.getModel();
        String cd = (String) combIntakecode.getSelectedItem();
        model.setRowCount(0);
        String intakefile = cd + ".txt";
        
      //temporary array to hold the data that is read from file 
        ArrayList<String> tempArray = new ArrayList<>();
        
      
        try {
            try (FileReader fr = new FileReader(intakefile)) {
                Scanner reader = new Scanner(fr);
                String line;
                String[] lineArr;

                while ((line = reader.nextLine()) != null) {
                    //splite each line to check if the search name is present.
                    lineArr = line.split(";");
                    if (lineArr[0].equals(searchFullname)) {
                        
                        //if the search name is present, add the old data
                        //plus the new data in to the temp array
                        tempArray.add(
                                lineArr[0] + ";"
                                + lineArr[1] + ";"
                                + lineArr[2] + ";"
                                + lineArr[3] + ";"
                                + lineArr[4] + ";"
                                + newPassword  + ";"
                                + newMobileNumber  + ";"
                                + newEmail);
                              
                              
                    } else {
                        
                        //if the search id doennot match, add the line as it is
                        tempArray.add(line);
                    }
                }

                fr.close();

            } catch (Exception e) {

            }
        } catch (Exception e) {

        }
        
         
        try{
            
            //open the print writer to write the data in temp array back to the file
            try(PrintWriter pr = new PrintWriter(intakefile)){
                
                for (String str : tempArray) {
                    pr.println(str);

                    JOptionPane.showMessageDialog(null, "Student Record Updated");
                }
                
                //close the file 

                pr.close();
                
            } catch (Exception e) {

           }
            
        }catch (Exception e) {

        } 
        
      
          
    }//GEN-LAST:event_btnModify2ActionPerformed

    private void CombIntakeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CombIntakeActionPerformed

       
        
        model = (DefaultTableModel) StudentRecordtable.getModel();

        String cd = (String) CombIntake.getSelectedItem();

        model.setRowCount(0);

        String intakefile = cd + ".txt";

        try {
            BufferedReader input = new BufferedReader(new FileReader(intakefile));
            String line = input.readLine();
            
            
            
            
            while (line != null) {
                //System.out.println(line);

                String[] records = line.split(";");

                String FullName = records[0];
                String TPNumber = records[1];
                String IntakeCode = records[2];
                String Gender = records[3];
                String ModuleName = records[4];
                String Password = records[5];
                String MobileNumber = records[6];
                String Email = records[7];
                
                model.addRow(new Object[]{FullName, TPNumber, IntakeCode, Gender, ModuleName,Password, MobileNumber, Email});
                line = input.readLine();
            }
            input.close();

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error");
        }


    }//GEN-LAST:event_CombIntakeActionPerformed

    private void txtSearch1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSearch1KeyReleased
      
    }//GEN-LAST:event_txtSearch1KeyReleased

    private void btnDelete1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDelete1ActionPerformed
        
    }//GEN-LAST:event_btnDelete1ActionPerformed

    private void btnBack1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBack1ActionPerformed
        
    }//GEN-LAST:event_btnBack1ActionPerformed

    private void btnView2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnView2ActionPerformed
       
    }//GEN-LAST:event_btnView2ActionPerformed

    private void btnModify3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModify3ActionPerformed
        
    }//GEN-LAST:event_btnModify3ActionPerformed

    private void CombIntake1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CombIntake1ActionPerformed
        
    }//GEN-LAST:event_CombIntake1ActionPerformed

    private void StudentRecordtableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_StudentRecordtableMouseClicked
        int i = StudentRecordtable.getSelectedRow();
        txtFullname.setText(model.getValueAt(i,0).toString());
        txtTPnumber.setText(model.getValueAt(i,1).toString());
        txtPassword.setText(model.getValueAt(i,5).toString());
        txtMobilenumber.setText(model.getValueAt(i,6).toString());
        txtEmail.setText(model.getValueAt(i,7).toString());
        
    }//GEN-LAST:event_StudentRecordtableMouseClicked

   
    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed

        String FullName = (txtFullname.getText() + (";"));
        String TPNumber = (txtTPnumber.getText()+ (";"));
        String IntakeCode = (combIntakecode.getSelectedItem().toString() + (";"));
        String Gender = (comGender.getSelectedItem().toString() + (";"));
        String ModuleName = (combModule.getSelectedItem().toString() + (";"));
        String Password = (txtPassword.getText().trim() + (";"));
        String MobileNumber = (txtMobilenumber.getText().trim() + (";"));
        String Email =  (txtEmail.getText().trim() + (";"));

         RegisterClass nn = new  RegisterClass(FullName,TPNumber,IntakeCode,Password,MobileNumber,Email,Gender,ModuleName);

        try {

            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(combIntakecode.getSelectedItem() + ".txt",true)));

            {
                //pw.write(System.getProperty("line.separator"));
                pw.write(FullName);
                pw.write(TPNumber);
                pw.write(IntakeCode);
                pw.write(Gender);
                pw.write(ModuleName);
                pw.write(Password);
                pw.write(MobileNumber);
                pw.write(Email);
                
                pw.println();
                pw.close();
                
                txtFullname.setText("");
                txtTPnumber.setText("");
                txtPassword.setText("");
                txtMobilenumber.setText("");
                txtEmail.setText("");

                JOptionPane.showMessageDialog(null, "New Student Added");

            }

        }

        catch(Exception e) {
            JOptionPane.showMessageDialog(null, "No New Student Added");
        }

        try
        {
            PrintWriter login = new PrintWriter(new BufferedWriter(new FileWriter("StudentPassword.txt",true)));

            login.write(System.getProperty("line.separator"));
            login.write(FullName);
            login.write(Password);
            login.close();
        }
        catch(IOException e)
        {
            JOptionPane.showMessageDialog(null, "Error in writing");
        }
        
         try
        {
           PrintWriter lo = new PrintWriter(new BufferedWriter(new FileWriter(combModule.getSelectedItem() + ".txt",true)));

            lo.write(System.getProperty("line.separator"));
            lo.write(IntakeCode);
            lo.write(ModuleName);
            lo.write(FullName);
            lo.write(TPNumber);
            lo.close();
        }
        catch(IOException e)
        {
            JOptionPane.showMessageDialog(null, "Error in writing");
        }

        /*try
        {

            FileWriter writer = new FileWriter("StudentRegister.txt",true);

            writer.write(FullName);
            writer.write(System.getProperty("line.separator"));
            writer.write(TPNumber);
            writer.write(System.getProperty("line.separator"));
            writer.write(IntakeCode);
            writer.write(System.getProperty("line.separator"));
            writer.write(CourseName);
            writer.write(System.getProperty("line.separator"));
            writer.write(MobileNumber);
            writer.write(System.getProperty("line.separator"));
            writer.write(Email);
            writer.write(System.getProperty("line.separator"));
            writer.write(Gender);
            writer.write(System.getProperty("line.separator"));
            writer.close();

            JOptionPane.showMessageDialog(null, "file created");

        }

        catch(Exception e) {
            JOptionPane.showMessageDialog(null, "No file created");
        }

        try
        {
            BufferedWriter login = new BufferedWriter(new FileWriter("StudentPassword.txt",true));

            login.write(TPNumber);
            login.write(System.getProperty("line.separator"));
            login.write(Password);
            login.write(System.getProperty("line.separator"));
            login.close();
        }
        catch(IOException e)
        {
            JOptionPane.showMessageDialog(null, "Error in writing");
        }*/
    }//GEN-LAST:event_btnSaveActionPerformed

    private void combIntakecodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combIntakecodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_combIntakecodeActionPerformed

    private void txtSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSearchKeyReleased
         String txt = txtSearch.getText();
        
         filter(txt);
    }//GEN-LAST:event_txtSearchKeyReleased

    private void txtSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchActionPerformed
       
    }//GEN-LAST:event_txtSearchActionPerformed

    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StudentRecord().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> CombIntake;
    private javax.swing.JComboBox<String> CombIntake1;
    private javax.swing.JTable StudentRecordtable;
    private javax.swing.JTable StudentRecordtable1;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnBack1;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnDelete1;
    private javax.swing.JButton btnModify2;
    private javax.swing.JButton btnModify3;
    private javax.swing.JButton btnSave;
    private javax.swing.JButton btnView2;
    private javax.swing.JComboBox<String> comGender;
    private javax.swing.JComboBox<String> combIntakecode;
    private javax.swing.JComboBox<String> combModule;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lblModule;
    public javax.swing.JTextField txtEmail;
    public javax.swing.JTextField txtFullname;
    public javax.swing.JTextField txtMobilenumber;
    public javax.swing.JTextField txtPassword;
    private javax.swing.JTextField txtSearch;
    private javax.swing.JTextField txtSearch1;
    public javax.swing.JTextField txtTPnumber;
    // End of variables declaration//GEN-END:variables
}
