
package xyz.attendance.management.system;

public class AttendanceClass {
    
    public String StudentName;
    public String TPNumber;
    public String Date;
    public String Starttime;
    public String Endtime;
    public String Intakecode;
    public String Module;
    
    
    AttendanceClass(){
        
    }
    
    AttendanceClass(String StudentName,String TPNumber,String Date,String Starttime,String Endtime,String Intakecode,String Module){
        
        this.StudentName=StudentName;
        this.TPNumber=TPNumber;
        this.Date=Date;
        this.Starttime= Starttime;
        this.Endtime=Endtime;
        this.Intakecode = Intakecode;
        this.Module = Module;
    }
    
    
     public String getStudentName()
    {
        return StudentName;
    }
    
    public String getTPNumber()
    {
        return TPNumber;
    }
    
    public String getDate()
    {
        return Date;
    }
    
    public String getStarttime()
    {
       return Starttime; 
    }
    
    public String getEndtime()
    {
       return Endtime; 
    }
     public String getIntakecode()
    {
       return Intakecode; 
    }
    
    public String getModule()
    {
       return Module; 
    }
    
    public void present()
    {
        
    }
    
    public void absent()
    {
        
    }
    
    public void late()
    {
        
    }
       
}
