package xyz.attendance.management.system;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class AdminClass {
    public int AdminID;

   
    public void Search()
    {
        
    }
    
    
    public void DeleteRecord()
    {
        
    }
    
    public void ModifyDetail()
    {
        
    }
    
    public void ModifyAbsentwithReason()
    {
        
       
    }
    
    public ArrayList <String> tempal=new ArrayList <>();
    public ArrayList <String> tempal0=new ArrayList <>();
    public String [] record;
    public String [] record0;
    
    
    public boolean loginpass(String name, String pass)
    {
    boolean R=false;
    try
    {
        BufferedReader br = new BufferedReader(new FileReader("Admin.txt"));
        
        String line;
        while((line = br.readLine())!=null)
        {
           
            String[] record = line.split(";");
             if(record[0].equals(name)&&record[3].equals(pass))
            {
                R=true;
            }
        }
        br.close();
    }
    catch(Exception e)
    {
        JOptionPane.showMessageDialog(null, e);
    }
    return R;
    }
        }

